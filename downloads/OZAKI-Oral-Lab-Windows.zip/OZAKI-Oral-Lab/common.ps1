﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:OralPort = 18765
$script:OralBase = 'http://127.0.0.1:18765'
$script:OralName = 'ozaki-oral-lab-local'
$script:OralTaskName = 'OZAKI Oral Lab | ' + [char]0x54ac + [char]0x5408 + [char]0x30b7 + [char]0x30df + [char]0x30e5 + [char]0x30ec + [char]0x30fc + [char]0x30bf + [char]0x30fc

function Assert-NoReparse([string]$Path) {
    $item = Get-Item -LiteralPath $Path -Force
    while ($null -ne $item) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'この場所にはリンク形式のフォルダが含まれています。アプリをPC内の通常のフォルダに展開し直してください。'
        }
        if ($item -is [IO.DirectoryInfo]) { $item = $item.Parent } else { $item = $item.Directory }
    }
}

function Get-OralBundle([string]$AppRoot = (Join-Path $PSScriptRoot 'app')) {
    $root = [IO.Path]::GetFullPath($AppRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
    Assert-NoReparse $root
    $manifestPath = Join-Path $root 'release.json'
    Assert-NoReparse $manifestPath
    $release = [IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
    if ($release.name -ne $script:OralTaskName -or
        $release.version -notmatch '^[a-f0-9]{16}(?:-windows)?$') {
        throw 'アプリの配布ファイルを確認できません。ZIP全体を展開し、展開先の「start.cmd」から開いてください。'
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $rootId = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($root.ToLowerInvariant()))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
    return @{ Root = $root; RootId = $rootId; Release = $release }
}

function Get-OralStatePath {
    if ($env:OZAKI_ORAL_STATE_DIR) { $dir = [IO.Path]::GetFullPath($env:OZAKI_ORAL_STATE_DIR) }
    else {
        if (-not $env:LOCALAPPDATA) { throw 'Windowsの保存先を確認できませんでした。現在のWindows利用者でサインインし直してお試しください。' }
        $dir = Join-Path $env:LOCALAPPDATA 'OZAKI-Oral-Lab'
    }
    [void][IO.Directory]::CreateDirectory($dir)
    Assert-NoReparse $dir
    return Join-Path $dir 'server-18765.json'
}

function Get-OralHealth {
    $request = [Net.HttpWebRequest]::Create($script:OralBase + '/__oral_health')
    $request.Proxy = $null
    $request.Timeout = 5000
    $request.ReadWriteTimeout = 5000
    $request.AllowAutoRedirect = $false
    $response = $null
    $reader = $null
    try {
        $response = $request.GetResponse()
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        return ($reader.ReadToEnd() | ConvertFrom-Json)
    }
    catch { Write-Verbose ('Local app health check: ' + $_.Exception.Message); return $null }
    finally { if ($reader) { $reader.Dispose() }; if ($response) { $response.Dispose() } }
}

function Test-OralHealth($Health, $Bundle) {
    return ($null -ne $Health -and $Health.application -eq $script:OralName -and
        $Health.version -eq $Bundle.Release.version -and $Health.rootId -eq $Bundle.RootId)
}

function Show-OralMessage([string]$Message) {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [void][Windows.Forms.MessageBox]::Show($Message, 'OZAKI Oral Lab')
    } catch { Write-Host $Message }
}
