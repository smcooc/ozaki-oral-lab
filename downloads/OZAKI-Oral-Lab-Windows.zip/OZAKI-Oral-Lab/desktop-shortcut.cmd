@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0desktop-shortcut.ps1"
exit /b %ERRORLEVEL%
