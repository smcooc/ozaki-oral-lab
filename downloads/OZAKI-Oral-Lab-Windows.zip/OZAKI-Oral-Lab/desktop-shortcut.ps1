﻿param([switch]$Quiet)
. (Join-Path $PSScriptRoot 'common.ps1')
try {
    $null = Get-OralBundle
    $desktop = [Environment]::GetFolderPath('Desktop')
    $linkPath = Join-Path $desktop 'OZAKI Oral Lab.lnk'
    $target = Join-Path $PSScriptRoot 'start.cmd'
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($linkPath)
    if ((Test-Path -LiteralPath $linkPath) -and $shortcut.TargetPath -ne $target) {
        throw '別のフォルダを開くOZAKI Oral Labのアイコンが既にあります。デスクトップの古いアイコンだけを削除してから、もう一度お試しください。アプリ本体のフォルダや症例を削除する必要はありません。'
    }
    $shortcut.TargetPath = $target
    $shortcut.WorkingDirectory = $PSScriptRoot
    $shortcut.Description = $script:OralTaskName
    $shortcut.IconLocation = (Join-Path $PSScriptRoot 'app.ico') + ',0'
    $shortcut.Save()
    $message = 'デスクトップに「OZAKI Oral Lab」のアイコンを作りました。今後はこのアイコンから開けます。展開したアプリのフォルダは移動せず、そのまま置いてください。'
    if ($Quiet) { Write-Output $message } else { Show-OralMessage $message }
} catch {
    if ($Quiet) { [Console]::Error.WriteLine($_.Exception.Message) } else { Show-OralMessage $_.Exception.Message }
    exit 1
}
