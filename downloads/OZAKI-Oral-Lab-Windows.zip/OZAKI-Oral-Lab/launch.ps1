﻿param([switch]$NoBrowser)
. (Join-Path $PSScriptRoot 'common.ps1')
try {
    $bundle = Get-OralBundle
    $health = Get-OralHealth
    if ($health -and -not (Test-OralHealth $health $bundle)) {
        throw '別のフォルダまたは古い版のアプリが起動しています。先にそのフォルダの「stop.cmd」で停止してから、このフォルダの「start.cmd」を開いてください。保存した症例の場所を変えないため、別の接続先には切り替えません。'
    }
    if (-not $health) {
        $serverPath = Join-Path $PSScriptRoot 'server.ps1'
        $arguments = @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', ('"' + $serverPath + '"'))
        $powershell = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $errorLog = Join-Path (Split-Path -Parent (Get-OralStatePath)) 'startup-error.txt'
        $outputLog = Join-Path (Split-Path -Parent $errorLog) 'startup-output.txt'
        # Close both inherited output pipes so a caller can finish while the server keeps running.
        $started = Start-Process -FilePath $powershell -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardError $errorLog -RedirectStandardOutput $outputLog -PassThru
        $until = [DateTime]::UtcNow.AddSeconds(30)
        do {
            Start-Sleep -Milliseconds 250
            $health = Get-OralHealth
            if (Test-OralHealth $health $bundle) { break }
            $started.Refresh()
        } while (-not $started.HasExited -and [DateTime]::UtcNow -lt $until)
        if (-not (Test-OralHealth $health $bundle)) {
            $started.Refresh()
            if (-not $started.HasExited) { $started.Kill() }
            if ($NoBrowser -and (Test-Path -LiteralPath $errorLog)) { Write-Host ([IO.File]::ReadAllText($errorLog)) }
            throw 'アプリを起動できませんでした。別のアプリが接続先（18765番）を使用しているか、Windowsが実行を止めた可能性があります。既に起動中のOZAKI Oral Labがあれば、そのフォルダの「stop.cmd」で停止してから再度お試しください。解決しなければ、この文をCodexにお知らせください。'
        }
    }
    if (-not $NoBrowser) {
        $edgePaths = @(${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA) |
            Where-Object { $_ } | ForEach-Object { Join-Path $_ 'Microsoft\Edge\Application\msedge.exe' }
        $edge = $edgePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
        $url = $script:OralBase + '/oral-simulator/'
        if ($edge) { Start-Process -FilePath $edge -ArgumentList @('--profile-directory=Default', ('--app=' + $url)) }
        else { Start-Process $url }
    }
    Write-Output ('OZAKI Oral Lab: ' + $script:OralBase + '/oral-simulator/ [' + $bundle.Release.version + ']')
} catch {
    if ($NoBrowser) { Write-Error $_.Exception.Message } else { Show-OralMessage $_.Exception.Message }
    exit 1
}
