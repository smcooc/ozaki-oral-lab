﻿param([string]$Root = (Join-Path $PSScriptRoot 'app'), [ValidateRange(1024,65535)][int]$Port = 18765, [switch]$NoState)
. (Join-Path $PSScriptRoot 'common.ps1')
if ($Port -ne 18765 -and -not $NoState) { throw 'Alternative ports are for isolated QA only. Use -NoState.' }
$script:OralPort = $Port
$bundle = Get-OralBundle $Root
$allowed = @{}
foreach ($relative in @($bundle.Release.files) + @('release.json')) {
    if ($relative -isnot [string] -or $relative -notmatch '^[A-Za-z0-9_./-]+$' -or
        $relative.StartsWith('/') -or $relative.Contains('..') -or $relative.Contains('//')) {
        throw 'Invalid release file list.'
    }
    $file = [IO.Path]::GetFullPath((Join-Path $bundle.Root $relative))
    if (-not $file.StartsWith($bundle.Root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid release path.' }
    Assert-NoReparse $file
    if ((Get-Item -LiteralPath $file).PSIsContainer) { throw 'A release entry is not a file.' }
    $allowed['/' + $relative] = $file
}
$mime = @{
    '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'
    '.css' = 'text/css; charset=utf-8'; '.json' = 'application/json; charset=utf-8'
    '.webmanifest' = 'application/manifest+json'; '.svg' = 'image/svg+xml'
    '.png' = 'image/png'; '.csv' = 'text/csv; charset=utf-8'; '.txt' = 'text/plain; charset=utf-8'
}
$statePath = if ($NoState) { $null } else { Get-OralStatePath }
$startTicks = (Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks.ToString()
$instance = [Guid]::NewGuid().ToString('N')
$health = [Text.Encoding]::UTF8.GetBytes((@{
    application = $script:OralName; version = $bundle.Release.version; rootId = $bundle.RootId
    processId = $PID; instance = $instance
} | ConvertTo-Json -Compress))
$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $script:OralPort)
$listener.Server.ExclusiveAddressUse = $true

function Send-Reply($Stream, [int]$Code, [string]$Type, [byte[]]$Bytes, [bool]$HeadOnly) {
    $reason = @{ 200 = 'OK'; 400 = 'Bad Request'; 403 = 'Forbidden'; 404 = 'Not Found'; 405 = 'Method Not Allowed'; 431 = 'Request Header Fields Too Large'; 500 = 'Internal Server Error' }[$Code]
    $headers = "HTTP/1.1 $Code $reason`r`nContent-Type: $Type`r`nContent-Length: $($Bytes.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nCross-Origin-Resource-Policy: same-origin`r`n"
    if ($Code -eq 405) { $headers += "Allow: GET, HEAD`r`n" }
    $headerBytes = [Text.Encoding]::ASCII.GetBytes($headers + "`r`n")
    $Stream.Write($headerBytes, 0, $headerBytes.Length)
    if (-not $HeadOnly) { $Stream.Write($Bytes, 0, $Bytes.Length) }
}

try {
    $listener.Start(32)
    if (-not $NoState) {
        $record = @{ processId = $PID; startTicks = $startTicks; rootId = $bundle.RootId; instance = $instance; serverPath = $PSCommandPath }
        [IO.File]::WriteAllText($statePath, ($record | ConvertTo-Json -Compress), [Text.Encoding]::UTF8)
    }
    # Keep several accepted sockets in a short-lived queue: an idle browser
    # preconnect must not block the module and service-worker downloads behind it.
    $clients = New-Object Collections.ArrayList
    while ($true) {
        while ($listener.Pending()) {
            $client = $listener.AcceptTcpClient()
            $client.ReceiveTimeout = 1500
            $client.SendTimeout = 5000
            $client.NoDelay = $true
            if ($clients.Count -ge 32) { $client.Close(); continue }
            [void]$clients.Add(@{ Client = $client; Buffer = New-Object IO.MemoryStream; Started = [DateTime]::UtcNow })
        }
        for ($i = $clients.Count - 1; $i -ge 0; $i--) {
            $entry = $clients[$i]
            $client = $entry.Client
            $stream = $client.GetStream()
            $done = $false
            try {
                if (([DateTime]::UtcNow - $entry.Started).TotalSeconds -gt 3) { $done = $true; continue }
                if (-not $stream.DataAvailable) { continue }
                $chunk = New-Object byte[] 4096
                $count = $stream.Read($chunk, 0, [Math]::Min($chunk.Length, $client.Available))
                if ($count -le 0) { $done = $true; continue }
                $entry.Buffer.Write($chunk, 0, $count)
                $text = [Text.Encoding]::ASCII.GetString($entry.Buffer.ToArray())
                $end = $text.IndexOf("`r`n`r`n")
                if ($entry.Buffer.Length -gt 16384) {
                    Send-Reply $stream 431 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Header too large.')) $false
                    $done = $true; continue
                }
                if ($end -lt 0) { continue }
                $done = $true
                $lines = $text.Substring(0, $end).Split(@("`r`n"), [StringSplitOptions]::None)
                if ($lines[0] -notmatch '^([A-Z]+) ([^ ]+) HTTP/1\.[01]$') {
                    Send-Reply $stream 400 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Invalid request.')) $false; continue
                }
                $method = $Matches[1]; $target = $Matches[2]
                $headOnly = $method -eq 'HEAD'
                if ($method -ne 'GET' -and -not $headOnly) {
                    Send-Reply $stream 405 'text/plain' ([Text.Encoding]::UTF8.GetBytes('GET and HEAD only.')) $false; continue
                }
                $hosts = @($lines | Select-Object -Skip 1 | Where-Object { $_ -match '^(?i)Host:' })
                if ($hosts.Count -ne 1 -or $hosts[0] -notmatch ('^Host:\s*127\.0\.0\.1:' + $Port + '\s*$')) {
                    Send-Reply $stream 403 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Host not allowed.')) $headOnly; continue
                }
                if ($target -notmatch '^/[^#]*$' -or $target.StartsWith('//')) {
                    Send-Reply $stream 400 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Invalid target.')) $headOnly; continue
                }
                $route = [Uri]::UnescapeDataString(($target -split '\?', 2)[0])
                if ($route.Contains('\') -or $route.Contains(':') -or $route.Contains('..') -or $route.Contains([char]0)) {
                    Send-Reply $stream 403 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Path not allowed.')) $headOnly; continue
                }
                if ($route -eq '/__oral_health') { Send-Reply $stream 200 'application/json' $health $headOnly; continue }
                if ($route -eq '/') { $route = '/index.html' }
                if ($route -eq '/oral-simulator/') { $route = '/oral-simulator/index.html' }
                if (-not $allowed.ContainsKey($route)) {
                    Send-Reply $stream 404 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Not found.')) $headOnly; continue
                }
                $file = $allowed[$route]
                Assert-NoReparse $file
                $bytes = [IO.File]::ReadAllBytes($file)
                $type = $mime[[IO.Path]::GetExtension($file).ToLowerInvariant()]
                if (-not $type) { $type = 'application/octet-stream' }
                Send-Reply $stream 200 $type $bytes $headOnly
            } catch {
                $done = $true
                # Do not log request targets: they may contain a case identifier.
                try { Send-Reply $stream 500 'text/plain' ([Text.Encoding]::UTF8.GetBytes('The app file is unavailable.')) $false } catch {}
            } finally {
                if ($done) { $entry.Buffer.Dispose(); $client.Close(); $clients.RemoveAt($i) }
            }
        }
        Start-Sleep -Milliseconds 10
    }
} finally {
    $listener.Stop()
    if (Get-Variable clients -ErrorAction SilentlyContinue) { foreach ($entry in $clients) { $entry.Buffer.Dispose(); $entry.Client.Close() } }
    if (-not $NoState -and (Test-Path -LiteralPath $statePath)) {
        try {
            $saved = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
            if ($saved.processId -eq $PID -and $saved.instance -eq $instance) { Remove-Item -LiteralPath $statePath }
        } catch {}
    }
}
