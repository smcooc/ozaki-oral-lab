﻿param([switch]$Quiet)
. (Join-Path $PSScriptRoot 'common.ps1')
try {
    $bundle = Get-OralBundle
    $statePath = Get-OralStatePath
    if (-not (Test-Path -LiteralPath $statePath)) {
        if ($Quiet) { Write-Output 'OZAKI Oral Labは停止しています。' } else { Show-OralMessage 'OZAKI Oral Labは既に停止しています。' }
        exit 0
    }
    $saved = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json
    if ($saved.rootId -ne $bundle.RootId -or $saved.serverPath -ne (Join-Path $PSScriptRoot 'server.ps1')) {
        throw '別のフォルダから起動したアプリです。起動したフォルダにある「stop.cmd」を開いてください。この操作では停止していません。'
    }
    $process = Get-Process -Id ([int]$saved.processId) -ErrorAction SilentlyContinue
    if ($process) {
        if ($process.StartTime.ToUniversalTime().Ticks.ToString() -ne $saved.startTicks -or $process.ProcessName -ne 'powershell') {
            throw '起動時の記録と現在のアプリが一致しないため、停止しませんでした。ほかのアプリは終了していません。この文をCodexにお知らせください。'
        }
        Stop-Process -Id $process.Id
        $process.WaitForExit(5000) | Out-Null
    }
    if (Test-Path -LiteralPath $statePath) { Remove-Item -LiteralPath $statePath }
    if (-not $Quiet) { Show-OralMessage 'OZAKI Oral Labの配信を停止しました。保存済みの症例はブラウザ内に残っています。作業を保存してから、アプリの画面を閉じてください。' }
} catch {
    if ($Quiet) { Write-Error $_.Exception.Message } else { Show-OralMessage $_.Exception.Message }
    exit 1
}
